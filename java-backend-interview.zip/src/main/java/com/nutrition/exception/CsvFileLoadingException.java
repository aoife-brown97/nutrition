package com.nutrition.exception;

public final class CsvFileLoadingException extends RuntimeException {

    public CsvFileLoadingException(Throwable cause) {
        super(cause);
    }
}
