package com.nutrition.dto;

public enum SortOrder {
    ASC,
    DESC
}
